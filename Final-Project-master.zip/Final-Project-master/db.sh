# Change DBPASSWORD, DBUSER, DBHOST and DBNAME to match the values
# your mysql_db_info file on the webdev server.

mysql --password='WSFMxVGKdxDC' --user='yshi13' --host='dbdev.cs.uiowa.edu' 'db_yshi13'