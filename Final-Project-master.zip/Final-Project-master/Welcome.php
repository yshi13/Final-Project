<?php
	include_once('header.php');
?>            
	
			<div class="jumbotron">
				<div class="container-narrow">
				  <br>
				  &nbsp;
				  <br>
				  &nbsp;
				  
				  <h1><font size=10 style="font-family:'Lobster'"><strong>Wage  Guard</strong></font></h1>
				  <p></p>
				  <p><font size=5 style="font-family:'Allan'">/weyj gahrd/</font></p>
				  <p></p>
				  
				  <a class="btn btn-large btn-1" data-toggle="modal" data-target="#elogin" style="margin-right:60px;">I am Employee</a>
							  
				  <a class="btn btn-large btn-2" data-toggle="modal" data-target="#nlogin">I am NPO</a>
				</div>
			</div>
			
<?php
	include_once('login-modal.php');
?>
			
<?php
	include_once('footer.php');
?>