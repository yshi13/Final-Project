<?php
	include_once "config.php";
	include_once "utils.php";
	include_once('hashutil.php');
?>	
	
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Handmade CSS -->
        <link href="style1.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		
		<link href='http://fonts.googleapis.com/css?family=Raleway:100' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
		
    </head>

    <body style="background-color: #6c6c76">
		<div class="row" style="background-color: white" width=100%>
			<div class="col-sm-10 col-xs-12 menu" width=100%>
				<br>
				<a href="Welcome.php" style="margin-left: 80px"><font style="font-size: 45px; font-family:'Lobster'; color: black"><strong>Wage  Guard</strong></font></a>
				<a href="login.php" style="margin-left: 50px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>LOG IN</strong></font></a>
				<a href="esignup.php" style="margin-left: 50px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>SIGN UP</strong></font></a>
				<a href="#" style="margin-left: 50px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>HELP</strong></font></a>
			</div>
			<div class="col-sm-2 col-xs-12" width=100% href="Welcome.php">
				<p></p>
				<a href="Welcome.php"><img alt="Capital W" src="logo.jpg" width=85 height=80></a>
				<p></p>
			</div>
		</div>
		<br>
		&nbsp;
			
	
	        
