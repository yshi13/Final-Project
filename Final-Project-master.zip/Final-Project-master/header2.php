<?php
// check if user logged in, if not, kick them to login.php
	session_start();
	if(!isset($_SESSION['eemail'])) {
		// if this is not set, it means they are not logged in
		header("Location: Welcome.php");
	}

?>

<?php
	include_once "config.php";
	include_once "utils.php";
?>
	
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Handmade CSS -->
        <link href="style2.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script src="sorttable.js"></script>
		
		<link href='http://fonts.googleapis.com/css?family=Raleway:100' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
		
    </head>

    <body style="background-color: #d4d4d4">
		<div class="row" style="background-color: white" width=100%>
			<div class="col-sm-10 col-xs-12 menu" width=100%>
				<br>
				<a href="dashboard.php" style="margin-left: 80px; margin-right: 30px"><img alt="avatar" src="avatar.png" width=60 height=60></a>
				<font size=2 style="font-family:'Raleway'; color: #6c6c76"><strong>Hello Joe!</strong></font>
				<a href="logout.php" style="margin-left: 50px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>Logout </strong></font></a>
				<a href="#" style="margin-left: 30px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>Notification </strong></font></a>
				<span class="glyphicon glyphicon-envelope"></span>
				<a href="#" style="margin-left: 30px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>Account Setting </strong></font></a>
				<span class="glyphicon glyphicon-cog"></span>
				<a href="#" style="margin-left: 30px"><font size=4 style="font-family:'Raleway'; color: #6c6c76"><strong>Help</strong></font></a>
			</div>
			<div class="col-sm-2 col-xs-12" width=100% href="Welcome.php">
				<p></p>
				<a href="dashboard.php"><img alt="Capital W" src="logo.jpg" width=85 height=80></a>
				<p></p>
			</div>
		</div>
		<br>
		&nbsp;
			
	
	        
