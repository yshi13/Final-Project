<?php
// Site configuration.

// Server information.
$Proto = "http://";
$Host = $_SERVER['SERVER_NAME'];
$Base = "/~yshi13/project/";

// Title to use in browser title bar.
$Title = "Wage Guard";
$Name = "Yi Shi";
$Email = "yi-shi-1@uiowa.edu";
$Logo = "logo.jpg";

// DB connection (from mysql_db_info).
$DBName = "db_yshi13";
$DBHost = "dbdev.cs.uiowa.edu";
$DBUser = "yshi13";
$DBPasswd = "WSFMxVGKdxDC";
?>
