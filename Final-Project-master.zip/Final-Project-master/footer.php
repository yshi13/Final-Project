            <br>
			&nbsp;
			<br>
			&nbsp;
			<div class="row-footer">
				<div class="col-xs-12" align="center">
						Copyright Group Se7ven 2016 | All Rights Reserved
						<a href="terms.html">Terms & Conditions</a> |
						<a href="privacy.html">Privacy Policy</a>
				</div>
			</div>
        </div>	
    </body>
</html>