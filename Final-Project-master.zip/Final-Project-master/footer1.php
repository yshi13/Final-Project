            <br>
			&nbsp;
			<br>
			&nbsp;
			<div class="row-footer">
				<div class="col-xs-12" style="font-family:'Raleway'; color: white" align="center">
						<strong>Copyright Group Se7ven 2016 | All Rights Reserved</strong>
						<a href="terms.html"><strong>Terms & Conditions</strong></a> |
						<a href="privacy.html"><strong>Privacy Policy</strong></a>
				</div>
			</div>
        </div>	
    </body>
</html>